# Qwentext Studios™ Digital Calculator

A lightweight, terminal-based calculator designed for speed and reliability. Built by **Qwentext Studios™**, this tool provides a crash-proof environment for essential arithmetic operations.

## Features
* **Five-Function Arithmetic:** Addition, Subtraction, Multiplication, Division, and Exponents.
* **Error Handling:** Built-in protection against non-integer inputs and division-by-zero errors.
* **Branded Interface:** Features the signature Qwentext Studios™ terminal styling.
* **Bit Limit Bypass [BLB]:** Can calculate numbers over the standard 64-bit integreter limit.

## Installation
To run this application, you must have **Python 3.x.x** installed on your system.

1. **Download the Source:** Save the `QTS-Cal.py` file to your local machine.
2. **Open Terminal/Command Prompt:** Navigate to the folder where you saved the file.
3. **Run the Application (Terminal/Bash):**

   ```bash
   python QTS-Cal{VERSIONID}.py
    ```
Replace {VERSIONID} with the id of your filename (e.g 110, 100).

This program may also be successfully activated by various other methods.

- - -
*Any crash-proof or fail-proof promise or notice is not guaranteed. This software may crash or fail due to your local machine's configuration, memory, or other external or internal factors.*


