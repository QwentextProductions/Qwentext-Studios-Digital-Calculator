# © 2026 Qwentext Studios™. All rights reserved.
# Unauthorized actions including but not limited to: 
# replication, modification, distribution, reverse engineering, or decompilation of this file, via any medium is strictly prohibited.
# THiS FILE IS AUTHORIZED TO BE USED FOR AUTOMATION WHEN POSSESING COMPLIANCE OF THE QWENTEXT STUDIOS™ S.S.L.A. v1.1.0
# For licensing information or distribution inquiries, please contact: support@qwentextstudios.com
# Version 1.1.0

# ==========================================================
# This piece of software is authorized to section 6 in the version 1.1.0 of the S.S.L.A
# Qwentext Studios™ is a branch of Qwentext Productions™
# SOFTWARE: FX_1-CALCULATOR
# VERSION: FX-1.0
# ==========================================================
# BRANCH:  Qwentext Studios™
# AUTHOR:  Ethan Alexander Zofchak, Lead Technical Officer (LTO)
# LICENSE: Qwentext Studios™ S.S.L.A. v1.1.0
# ==========================================================

import time

# System Initialization
cycles = 0
start_time = time.time()

print("FX-{STARTED}")
print("CMD=['1'== calculate, '2'== display info, '3'== quit]")
print("OPTYPE=['1'== add., '2'== sub., '3'== mul., '4'== div., '5'== exp.]")

while True:
    print("\nFX_CYCLE-{READY}")
    cj = input(">> ")

    # COMMAND 3: TERMINATE PROCESS
    if cj == "3":
        print("FX-{STOPPED}")
        break 

    # COMMAND 2: SYSTEM TELEMETRY
    elif cj == "2":
        print("FX-INFO-{STARTED}")
        print(f"Cycles completed: {cycles}")
        print(f"SESSION UPTIME: {round(time.time() - start_time, 2)}s")
        print(f"LICENSE: S.S.L.A. 1.1.0 (SECTION 6 ACTIVE)")
        print("Version: FX-1.0")

    # COMMAND 1: CALCULATION ENGINE
    elif cj == "1":
        try:
            print("Select='NUM~1':")
            num1 = int(input(">> "))
            print("Select='NUM~2':")
            num2 = int(input(">> "))

            print("Select='OPTYPE':")
            optype = input(">> ")
            
            ## OPERATION FUNCTIONS ##
            if optype == "1":
                print(f"RESULT: {num1 + num2}")
                cycles += 1
            elif optype == "2":
                print(f"RESULT: {num1 - num2}")
                cycles += 1
            elif optype == "3":
                print(f"RESULT: {num1 * num2}")
                cycles += 1
            elif optype == "4":
                if num2 == 0:
                    print("ERROR-?={DIVISION_BY_ZERO}")
                else:
                    print(f"RESULT: {num1 / num2}")
                    cycles += 1
            elif optype == "5":
                print(f"RESULT: {num1 ** num2}")
                cycles += 1
            else:
                print("ERROR-?={INVALID_OPTYPE}")
                
        except ValueError:
            print("ERROR-?={NON_NUMERIC_INPUT}")
            print("Action: FX_CYCLE-ABORTED")

    # INVALID COMMAND HANDLER (Fixed Indentation)
    else:
        print("ERROR-?={INVALID_CMD}")